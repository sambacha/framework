```js
import { Sandbox } from '../sandbox';

const sandbox = new Sandbox();
sandbox.listen(8911, 'localhost'); // => Promise
```
