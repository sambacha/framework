/**
 * 
 */
export enum SignatureKind {
  ETH_SIGN = 0,
}