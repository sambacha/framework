import { DefaultReporter } from '@hayspec/reporter';

/**
 * 
 */
export class Reporter extends DefaultReporter {}