# Change Log - @specron/spec

This log was last generated on Thu, 28 Nov 2019 11:45:10 GMT and should not be manually modified.

## 0.10.0
Thu, 28 Nov 2019 11:45:10 GMT

*Version update only*

## 0.9.0
Tue, 01 Oct 2019 18:29:23 GMT

*Version update only*

## 0.8.2
Tue, 01 Oct 2019 18:27:47 GMT

*Version update only*

## 0.8.1
Tue, 01 Oct 2019 18:14:09 GMT

*Version update only*

## 0.8.0
Sun, 29 Sep 2019 22:26:46 GMT

*Version update only*

## 0.7.0
Tue, 30 Jul 2019 13:07:02 GMT

*Version update only*

## 0.5.6
Tue, 26 Feb 2019 12:05:55 GMT

*Version update only*

## 0.5.5
Tue, 26 Feb 2019 11:54:20 GMT

*Initial release*

